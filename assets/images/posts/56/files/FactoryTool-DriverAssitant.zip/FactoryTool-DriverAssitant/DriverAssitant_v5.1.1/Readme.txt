Installer en premier les pilotes via Driver Assistant
Installer ensuite le logiciel Factory Tool

